Homescreen widgets can only be applied to the user's Homescreen.

See here for further information: https://incendo.ws/documentation/widget-api/additional-documentation/widget-layout.html
