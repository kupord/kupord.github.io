#import <UIKit/UIKit.h>

@interface UIImage (Average)
@property (strong, readonly, nonatomic) UIColor *averageColor;

@end